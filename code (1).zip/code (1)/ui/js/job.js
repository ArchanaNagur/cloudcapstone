$(document).ready(function () {
  document.getElementsByClassName('tablinks')[0].click()
    jobList();
  });

  // Get all jobs to display
  function jobList() {
    // Call Web API to get a list of jobs
    $.ajax({
      url: 'http://EC2Co-EcsEl-1LX38L2YLS2W1-489218104.us-east-2.elb.amazonaws.com/getall',
      type: 'POST',
      dataType: 'json',
      success: function (jobs) {

        
          
        $.each(jobs, function (index, job) {


     
         if ($("#jobTable tbody").length == 0) {
           $("#jobTable").append("<tbody></tbody>");
         }
     
         // Append row to <table>
         $("#jobTable tbody").append("<tr>" +
         "<td>" + job.id + "</td>" +
         "<td>" + job.title + "</td>" +
         "<td>" + job.company + "</td>" +
       "</tr>");
         });
     
      },
      error: function (request, message, error) {
        handleException(request, message, error);
      }
    });
  }
 



  // Handle click event on Add button
  function addjob() {
    job = new Object();
    job.id = $("#jobid").val();
    job.company = $("#jobcompany").val();
    job.title = $("#jobtitle").val();

    if ($("#updateButton").text().trim() == "Add") {
      jobAdd(job);
    }
  }
  function jobAdd(job) {
    // Call Web API to add a new job
    $.ajax({
      url: "http://127.0.0.1/new",
      type: 'POST',
      contentType: "application/json;charset=utf-8",
      data:JSON.stringify(job),

      success: function (job) {

        jobAddSuccess(job);
      },
      error: function (request, message, error) {
        handleException(request, message, error);
      }
    });
  }
  function jobformClear() {
    $("#jobid").val('');
    $("#jobtitle").val('');
    $("#jobcompany").val('');
  }
  function jobAddSuccess(job) {
  jobList()
    jobformClear();
  }

  // Handle exceptions from AJAX calls
  function handleException(request, message, error) {
    var msg = "";

    msg += "Code: " + request.status + "\n";
    msg += "Text: " + request.statusText + "\n";
    if (request.responseJSON != null) {
      msg += "Message" + request.responseJSON.Message + "\n";
    }

    alert(msg);
  }
from flask import Flask
from flask_restful import Resource, Api
from flask_restful import reqparse
from flask_mysqldb import MySQL

from flask_cors import CORS

mysql = MySQL()
app = Flask(__name__)

# MySQL configurations
app.config['MYSQL_USER'] = 'Root'
app.config['MYSQL_PASSWORD'] = 'admin123'
app.config['MYSQL_DB'] = 'cloudcapstone '
app.config['MYSQL_HOST'] = 'localhost'


mysql.init_app(app)

api = Api(app)


# enable CORS
CORS(app, resources={r'/*': {'origins': '*'}})
class get_all_records(Resource):
    def post(self):
  
            # Parse the arguments


            conn = mysql.connect
            cursor = conn.cursor()

            select_stmt = "SELECT * FROM jobs"
            cursor.execute(select_stmt)
            data = cursor.fetchall()

            items_list=[];
            for item in data:
                i = {
                    'id':item[0],
                    'title':item[1],
                    'company':item[2]

                }
                items_list.append(i)
            print(items_list)
            return items_list


       
                

class new_record(Resource):
    def post(self):

            # Parse the arguments
            parser = reqparse.RequestParser()
            parser.add_argument('id', type=int)
            parser.add_argument('title', type=str)
            parser.add_argument('company', type=str)

            args = parser.parse_args()

            print(args['title'])
            conn = mysql.connect
            cursor = conn.cursor()
            insert_stmt = (
            "INSERT INTO jobs (id,title,company)"
            "VALUES (%s, %s, %s)"
            )
            data = (args['id'],args['title'],args['company'])
            cursor.execute(insert_stmt, data)
            data = cursor.fetchall()

            if len(data) is 0:
                conn.commit()
                return {'StatusCode':'200','Message': 'success'}
            else:
                return {'StatusCode':'1000','Message': str(data[0])}






api.add_resource(new_record, '/new')
api.add_resource(get_all_records, '/getall')
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80,debug=False)

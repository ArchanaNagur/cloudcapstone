## app_py_candidate.py

from flask import Flask
from flask_restful import Resource, Api
from flask_restful import reqparse
from flask_mysqldb import MySQL
from flask_cors import CORS



mysql = MySQL()
app = Flask(__name__)

# MySQL configurations
app.config['MYSQL_USER'] = 'Root'
app.config['MYSQL_PASSWORD'] = 'admin123'
app.config['MYSQL_DB'] = 'cloudcapstone'
app.config['MYSQL_HOST'] = 'localhost'


mysql.init_app(app)

api = Api(app)


# enable CORS
CORS(app, resources={r'/*': {'origins': '*'}})

class get_all_records(Resource):
    def post(self):

            # Parse the arguments


            conn = mysql.connect
            cursor = conn.cursor()
            select_stmt = "SELECT * FROM candidates"
            cursor.execute(select_stmt)
            data = cursor.fetchall()

            items_list=[];
            for item in data:
                i = {
                    'id':item[0],
                    'name':item[1],
                    'skill':item[2],
                    'email':item[3]
                }
                items_list.append(i)
            return items_list

        
                

class new_record(Resource):
    def post(self):

            # Parse the arguments
            parser = reqparse.RequestParser()
            parser.add_argument('id', type=int)
            parser.add_argument('name', type=str)
            parser.add_argument('email', type=str)
            parser.add_argument('skill', type=str)
            args = parser.parse_args()


            conn = mysql.connect
            cursor = conn.cursor()
            insert_stmt = (
            "INSERT INTO candidates (id,name,skill,email)"
            "VALUES (%s, %s, %s, %s)"
            )
            data = (args['id'],args['name'],args['skill'],args['email'])
            cursor.execute(insert_stmt, data)
            data = cursor.fetchall()

            if len(data) is 0:
                conn.commit()
                return {'StatusCode':'200','Message': 'success'}
            else:
                return {'StatusCode':'1000','Message': str(data[0])}







api.add_resource(new_record, '/new')
api.add_resource(get_all_records, '/getall')

if __name__ == '__main__':
            app.run(host='0.0.0.0', port=80,debug=False)

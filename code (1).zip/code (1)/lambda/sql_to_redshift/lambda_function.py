import json
import boto3
from sqlalchemy import create_engine
def lambda_handler(event, context):
    bucket_name = 'mastercloudbucket'
    prefix = 'analytic_job/temp.csv'

    engine = create_engine('mysql+mysqlconnector://Root:admin123@cloudcapstone.c9fr2oahrgai.us-east-2.rds.amazonaws.com:3306/cloudcapstone')

    connection = engine.connect()
    candidate_count= connection.execute('SELECT count(*) FROM candidates').fetchone()[0]
    job_count = connection.execute('SELECT count(*) FROM jobs').fetchone()[0]
    customer_count = connection.execute('SELECT count(*) FROM customers').fetchone()[0]

    s3 = boto3.client('s3')
    s3.put_object(Body="{0},{1},{2}".format(candidate_count,job_count,customer_count), Bucket=cloudmasters3bucket, Key=prefix)
    
    engine = create_engine("postgresql://root:Admin123@cloudredshift.cmjpmcdkyvuf.us-east-2.redshift.amazonaws.com:5439/prod")

    connection = engine.connect()
    candidate_count= connection.execute("copy edureka_ca_analytics.edureka_ca_table(candidates,customers,jobs) from 's3://{0}/{1}' delimiter ',' dateformat 'auto' timeformat 'auto' ignoreheader 0 iam_role 'arn:aws:iam::475925134984:role/edurekacarole'".format(bucket_name,prefix))
    

   
    
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
event = ''
context = ''
lambda_handler(event,context)


CREATE TABLE candidates(id int,name varchar(100),skill varchar(100),email varchar(100));
CREATE TABLE jobs(id int,company varchar(100),title varchar(100));
CREATE TABLE customers(id int,company varchar(100),email varchar(100));

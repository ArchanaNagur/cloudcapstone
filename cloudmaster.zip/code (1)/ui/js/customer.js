$(document).ready(function () {
    document.getElementsByClassName('tablinks')[0].click()
    customerList();
  });

  // Get all customers to display
  function customerList() {
    // Call Web API to get a list of customers
    $.ajax({
      url: 'http://EC2Co-EcsEl-N96RROVM1G58-799792486.us-east-2.elb.amazonaws.com/getall',
      type: 'POST',
      dataType: 'json',
      success: function (customers) {

        
          
        $.each(customers, function (index, customer) {



     
         if ($("#customerTable tbody").length == 0) {
           $("#customerTable").append("<tbody></tbody>");
         }
     
         // Append row to <table>
         $("#customerTable tbody").append("<tr>" +
         "<td>" + customer.id + "</td>" +
         "<td>" + customer.name + "</td>" +
         "<td>" + customer.email + "</td>" +
       "</tr>");
         });
     
      },
      error: function (request, message, error) {
        handleException(request, message, error);
      }
    });
  }
 



  // Handle click event on Add button
  function addcustomer() {
    customer = new Object();
    customer.id = $("#customerid").val();
    customer.name = $("#customername").val();
    customer.email = $("#customeremail").val();

    if ($("#updateButton").text().trim() == "Add") {
      customerAdd(customer);
    }
  }
  function customerAdd(customer) {
    console.log(customer)
    // Call Web API to add a new customer
    $.ajax({
      url: "http://127.0.0.1/new",
      type: 'POST',
      contentType: "application/json;charset=utf-8",
      data:JSON.stringify(customer),

      success: function (customer) {

        customerAddSuccess(customer);
      },
      error: function (request, message, error) {
        handleException(request, message, error);
      }
    });
  }
  function formClear() {
    $("#customerid").val('');
    $("#customername").val('');

    $("#customeremail").val('');
  }
  function customerAddSuccess(customer) {
  customerList()
    formClear();
  }

  // Handle exceptions from AJAX calls
  function handleException(request, message, error) {
    var msg = "";

    msg += "Code: " + request.status + "\n";
    msg += "Text: " + request.statusText + "\n";
    if (request.responseJSON != null) {
      msg += "Message" + request.responseJSON.Message + "\n";
    }

    alert(msg);
  }
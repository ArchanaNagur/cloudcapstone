var bucketname = 'edurekas3bucketcreation';
var s3 = new AWS.S3({
  apiVersion: '2006-03-01',
  params: {Bucket: bucketname}
});

$(document).ready(function () {
    document.getElementsByClassName('tablinks')[0].click()
    candidateList();
  });

  // Get all candidates to display
  function candidateList() {
    // Call Web API to get a list of candidates
    $.ajax({
      url: 'http://EC2Co-EcsEl-18S0Z8TEBI5S2-1549162739.us-east-2.elb.amazonaws.com/getall',
      type: 'POST',
      dataType: 'json',
      success: function (candidates) {

        
          
        $.each(candidates, function (index, candidate) {


           // Add a row to the candidate table

     
         if ($("#candidateTable tbody").length == 0) {
           $("#candidateTable").append("<tbody></tbody>");
         }
     
         // Append row to <table>
         $("#candidateTable tbody").append("<tr>" +
         "<td>" + candidate.id + "</td>" +
         "<td>" + candidate.name + "</td>" +
         "<td>" + candidate.skill + "</td>" +
         "<td>" + candidate.email + "</td>" +
       "</tr>");
         });
     
      },
      error: function (request, message, error) {
        handleException(request, message, error);
      }
    });
  }
 



  // Handle click event on Add button
  function addCandidate() {
    candidate = new Object();
    candidate.id = $("#candidateid").val();
    candidate.name = $("#candidatename").val();
    candidate.skill = $("#candidateskill").val();
    candidate.email = $("#candidateemail").val();

    if ($("#updateButton").text().trim() == "Add") {
      candidateAdd(candidate);
    }
  }
  function AddResume(){
    if (!files.length) {
      return alert('Please choose a file to upload first.');
    }
    var file = files[0];
    var fileName = file.name;
    var actual_key ='inputresumes/'+fileName
    s3.upload({
      Key: actual_key,
      Body: file
    }, function(err, data) {
      if (err) {
          console.log(file)

          console.log(err.message)

          return alert('There was an error uploading your resume: ', err.message);
      }
      jQuery(".loader_div").hide();
      alert('Successfully uploaded resume.');
     });
  

  }
  function candidateAdd(candidate) {
    // Call Web API to add a new candidate
    $.ajax({
      url: "http://127.0.0.1/new",
      type: 'POST',
      contentType: "application/json;charset=utf-8",
      data:JSON.stringify(candidate),

      success: function (candidate) {

        candidateAddSuccess(candidate);
      },
      error: function (request, message, error) {
        handleException(request, message, error);
      }
    });
  }
  function candidateformClear() {
    $("#candidateid").val('');
    $("#candidatename").val('');
     $("#candidateskill").val('');
    $("#candidateemail").val('');
  }
  function candidateAddSuccess(candidate) {
  candidateList()
    candidateformClear();
  }

  // Handle exceptions from AJAX calls
  function handleException(request, message, error) {
    var msg = "";

    msg += "Code: " + request.status + "\n";
    msg += "Text: " + request.statusText + "\n";
    if (request.responseJSON != null) {
      msg += "Message" + request.responseJSON.Message + "\n";
    }

    alert(msg);
  }

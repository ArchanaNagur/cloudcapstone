from flask import Flask
from flask_restful import Resource, Api
from flask_restful import reqparse
from flask_mysqldb import MySQL
from flask_cors import CORS


mysql = MySQL()
app = Flask(__name__)

# MySQL configurations
app.config['MYSQL_USER'] = 'Root'
app.config['MYSQL_PASSWORD'] = 'admin123'
app.config['MYSQL_DB'] = 'cloudcapstone'
app.config['MYSQL_HOST'] = 'localhost'


mysql.init_app(app)

api = Api(app)


# enable CORS
CORS(app, resources={r'/*': {'origins': '*'}})
class get_all_records(Resource):
    def post(self):
        try: 
            # Parse the arguments
            conn = mysql.connect
            cursor = conn.cursor()
            select_stmt = "SELECT * FROM customers"
            cursor.execute(select_stmt)
            data = cursor.fetchall()
            items_list=[]
            for item in data:
                i = {
                    'id':item[0],
                    'name':item[1],
                    'email':item[2]
                }
                items_list.append(i)

            return items_list

        except Exception as e:
            return {'error': str(e)}






        
                

class new_record(Resource):
    def post(self):

            parser = reqparse.RequestParser()
            parser.add_argument('id', type=int)
            parser.add_argument('name', type=str)
            parser.add_argument('email', type=str)
            args = parser.parse_args()
            print(args['id'],args['name'],args['email'])

            conn = mysql.connect
            cursor = conn.cursor()
            insert_stmt = (
            "INSERT INTO customers (id,name,email)"
            "VALUES (%s, %s, %s)"
            )
            data = (args['id'],args['name'],args['email'])

            cursor.execute(insert_stmt, data)
            data = cursor.fetchall()

            if len(data) is 0:
                conn.commit()
                return {'StatusCode':'200','Message': 'success'}
            else:
                return {'StatusCode':'1000','Message': str(data[0])}






api.add_resource(new_record, '/new')
api.add_resource(get_all_records, '/getall')
if __name__ == '__main__':
        app.run(host='0.0.0.0', port=80,debug=False)


import boto3
import PyPDF2
import os
import json
def lambda_handler(event, context):
        s3 = boto3.client('s3')
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        key_name = event['Records'][0]['s3']['object']['key']
        s3.download_file(bucket_name, key_name ,'/tmp/{0}'.format(os.path.split(key_name)[1]))
        pdf_path = '/tmp/{0}'.format(os.path.split(key_name)[1])
        pdf = PyPDF2.PdfFileReader(open(pdf_path, "rb"))

        pdftext = '' 
        for page in pdf.pages:

            pdftext=pdftext+ page.extractText()
        
        s3.put_object(Body=pdftext, Bucket=bucket_name, Key='extractedresumes/{0}'.format(os.path.split(key_name)[1]).replace('.pdf','.txt'))

        os.remove(pdf_path)
        return {
        'statusCode': 200,
        'body': json.dumps('Successfully extracted and dumped')
        }